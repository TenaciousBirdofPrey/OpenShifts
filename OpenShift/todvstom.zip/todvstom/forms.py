from django import forms
    
class SevenDaySelect(forms.Form):
    select_date = forms.DateField(help_text="Enter a date ")