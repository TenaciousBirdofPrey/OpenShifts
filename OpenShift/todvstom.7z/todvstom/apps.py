from django.apps import AppConfig


class TodvstomConfig(AppConfig):
    name = 'todvstom'
